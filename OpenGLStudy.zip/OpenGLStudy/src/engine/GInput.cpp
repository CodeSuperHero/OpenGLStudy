#include "engine/GInput.h"

namespace OSEngine
{
    Camera* GInput::camera;
    vec2 GInput::mousePosition;
    GLFWwindow* GInput::window;
}