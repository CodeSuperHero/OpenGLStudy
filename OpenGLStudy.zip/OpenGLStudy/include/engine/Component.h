#pragma once
#include "engine/OSObject.h"

namespace OSEngine
{
    class Component : OSObject
    {
    public:
        Component() {}
        virtual ~Component() {  }
    protected:

    };
}