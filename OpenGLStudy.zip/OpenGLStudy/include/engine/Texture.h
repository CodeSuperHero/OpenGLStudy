#pragma once
#include <iostream>

#include "engine/Engine.h"

namespace OSEngine
{
    struct TextureS
    {
        std::string type;
        unsigned int id;
    };
}